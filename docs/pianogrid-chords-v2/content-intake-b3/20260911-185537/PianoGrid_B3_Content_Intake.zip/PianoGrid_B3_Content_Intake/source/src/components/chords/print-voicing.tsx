import { Keyboard } from '../a-minor/keyboard';
import { SITE_NAME } from '@/lib/site-config';
import type { Voicing } from '@/lib/a-minor-types';
export function PrintVoicing({voicing,whitePitchClasses,title,tones,formula,url,disclaimer}:{voicing:Voicing;whitePitchClasses:number[];title:string;tones:string[];formula:string[];url:string;disclaimer:string}) {
 return <><div className="am-print-brand">{SITE_NAME}</div><div className="am-print-title">{title}</div><p className="am-print-lead">Chord tones: {tones.join('–')} · Formula: {formula.map(n=>n.replace('b','♭')).join(', ')}</p><div className="am-print-selection"><div><h2>{voicing.inversion_label}</h2><div className="am-print-notes">{voicing.print_data.spelled_pitches.join(' – ')}</div></div><div><strong>{voicing.chord_symbol}</strong><div>Bass: {voicing.bass_spelling}</div></div></div><Keyboard voicing={voicing} whitePitchClasses={whitePitchClasses} print/><p className="am-print-helper">Dots mark the notes to play. C4 is middle C. Numbers identify octaves, not fingers.</p><div className="am-print-footer">{disclaimer}<br/>{url} · Current position reference</div></>;
}
